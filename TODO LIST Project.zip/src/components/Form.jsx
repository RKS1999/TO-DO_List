import { useDispatch, useSelector } from 'react-redux';
import { changeList, addList } from '../Features/Store/Store';

function Form() {
  const dispatch = useDispatch();
  const list = useSelector(state => state.form.list);

  const handleListChange = event => {
    dispatch(changeList(event.target.value));
  };

  const handleSubmit = event => {
    event.preventDefault();
    dispatch(addList({ list }));
  };

  return (
    <div className="container-fluid">
      <hr />
      <h3 className="subtitle is-3" style={{ color: "#87CEEB" }}>TODO List</h3>
      <form onSubmit={handleSubmit}>
        <div className="mb-3 input-group" style={{ display: "flex", justifyContent: "center" }}>
          <span className="input-group-text" id="basic-addon1" style={{ color: "#87CEEB" }}>Add New List</span>
          <input
            type="text"
            className="input is-expanded"
            value={list}
            onChange={handleListChange}
          />
        </div>
        <button type="submit" className="btn btn-info" style={{ color: "white" }}>Submit</button>
      </form>
      <br />
    </div>
  );
}

export default Form;
